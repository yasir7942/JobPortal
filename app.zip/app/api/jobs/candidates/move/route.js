export const runtime = "nodejs";

import qs from "qs";

/* ---------------- BASE URLS ---------------- */

function strapiBase() {
    return (process.env.NEXT_PUBLIC_API_BASE_URL || "").trim().replace(/\/$/, "");
}

function strapiPublicBase() {
    return (process.env.NEXT_PUBLIC_STRAPI_PUBLIC_URL || "").trim().replace(/\/$/, "");
}

function strapiToken() {
    return process.env.STRAPI_TOKEN || "";
}

/* ---------------- HELPERS ---------------- */

async function readBodySafe(res) {
    const text = await res.text();

    try {
        return text ? JSON.parse(text) : null;
    } catch {
        return { raw: text };
    }
}

function relationId(value) {
    if (!value) return null;

    const v = value?.data ?? value;

    if (typeof v === "object" && v !== null) return v.id ?? null;
    if (typeof v === "number") return v;

    return null;
}

function absoluteMediaUrl(url) {
    const s = String(url || "").trim();
    if (!s) return "";
    if (/^https?:\/\//i.test(s)) return s;

    return `${strapiPublicBase()}${s.startsWith("/") ? "" : "/"}${s}`;
}

function normalizeOfferLetterMedia(media) {
    const m = media?.data ?? media;
    const attrs = m?.attributes ?? m;

    const id = m?.id ?? null;
    const name = attrs?.name ?? "";
    const url = attrs?.url ?? "";

    if (!id && !name && !url) return null;

    return {
        id,
        name,
        url: absoluteMediaUrl(url),
    };
}

function toProcessString(action) {
    const v = String(action || "").trim().toLowerCase();

    if (v === "shortlisted" || v === "shortlisted candidate") {
        return "Shortlisted Candidate";
    }

    if (
        v === "interview" ||
        v === "requested interview" ||
        v === "request interview" ||
        v === "requested interview candidate"
    ) {
        return "Requested Interview";
    }

    if (v === "hired" || v === "hired candidate") {
        return "Hired Candidate";
    }

    return "Suggested Candidate";
}

function sanitizeAssignmentRow(row) {
    return {
        candidate: relationId(row?.candidate),
        candidateProcessList: row?.candidateProcessList || "Suggested Candidate",
        requestedInterviewDate: row?.requestedInterviewDate || null,
        offerLetter: relationId(row?.offerLetter) || null,
    };
}

function sanitizeAssignmentRows(rows) {
    return (Array.isArray(rows) ? rows : [])
        .map(sanitizeAssignmentRow)
        .filter((row) => row?.candidate);
}

/* ---------------- API CALLS ---------------- */

async function getCandidateId(base, token, documentId) {
    const res = await fetch(
        `${base}/candidates/${documentId}?status=published`,
        {
            headers: {
                Authorization: `Bearer ${token}`,
            },
            cache: "no-store",
        }
    );

    const json = await readBodySafe(res);

    if (!res.ok || json?.error) {
        throw new Error(json?.error?.message || "Candidate fetch failed");
    }

    const candidateId = json?.data?.id;

    if (!candidateId) {
        throw new Error("Candidate id not found");
    }

    return candidateId;
}

async function getJobAssignments(base, token, jobDocumentId) {
    const query = qs.stringify(
        {
            status: "published",
            populate: {
                assignCandidatesToJob: {
                    populate: {
                        candidate: {
                            fields: ["id"],
                        },
                        offerLetter: {
                            fields: ["id", "name", "url"],
                        },
                    },
                },
            },
        },
        { encodeValuesOnly: true }
    );

    const res = await fetch(`${base}/jobs/${jobDocumentId}?${query}`, {
        headers: {
            Authorization: `Bearer ${token}`,
        },
        cache: "no-store",
    });

    const json = await readBodySafe(res);

    if (!res.ok || json?.error) {
        throw new Error(json?.error?.message || "Job fetch failed");
    }

    const job = json?.data || null;

    return Array.isArray(job?.assignCandidatesToJob)
        ? job.assignCandidatesToJob
        : Array.isArray(job?.attributes?.assignCandidatesToJob)
            ? job.attributes.assignCandidatesToJob
            : [];
}

async function updateJobAssignments(base, token, jobDocumentId, rows) {
    const payload = {
        data: {
            assignCandidatesToJob: rows,
        },
    };

    const res = await fetch(
        `${base}/jobs/${jobDocumentId}?status=published`,
        {
            method: "PUT",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
        }
    );

    const json = await readBodySafe(res);

    if (!res.ok || json?.error) {
        console.error("UPDATE JOB PAYLOAD", JSON.stringify(payload, null, 2));
        console.error("UPDATE JOB RESPONSE", json);
        throw new Error(json?.error?.message || "Update job failed");
    }

    return json;
}

async function uploadOfferLetter(base, token, file) {
    const fd = new FormData();
    fd.append("files", file, file?.name || "offer-letter");

    const res = await fetch(`${base}/upload`, {
        method: "POST",
        headers: {
            Authorization: `Bearer ${token}`,
        },
        body: fd,
    });

    const json = await readBodySafe(res);

    if (!res.ok || json?.error) {
        throw new Error(json?.error?.message || "Upload failed");
    }

    const uploaded = Array.isArray(json) ? json[0] : null;

    if (!uploaded?.id) {
        throw new Error("Offer letter upload failed");
    }

    return {
        id: uploaded.id,
        name: uploaded.name || "",
        url: absoluteMediaUrl(uploaded.url || ""),
    };
}

async function updateCandidateJobStatus(base, token, candidateDocumentId, nextJobStatus) {
    const payload = {
        data: {
            jobStatus: nextJobStatus,
        },
    };

    const res = await fetch(
        `${base}/candidates/${candidateDocumentId}?status=published`,
        {
            method: "PUT",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
        }
    );

    const json = await readBodySafe(res);

    if (!res.ok || json?.error) {
        console.error("CANDIDATE STATUS PAYLOAD", JSON.stringify(payload, null, 2));
        console.error("CANDIDATE STATUS RESPONSE", json);
        throw new Error(json?.error?.message || "Failed to update candidate jobStatus");
    }

    return json;
}

/* ---------------- GET ---------------- */

export async function GET(req) {
    try {
        const base = strapiBase();
        const token = strapiToken();

        if (!base) {
            return Response.json(
                { ok: false, error: "Missing NEXT_PUBLIC_API_BASE_URL env" },
                { status: 500 }
            );
        }

        if (!token) {
            return Response.json(
                { ok: false, error: "Missing STRAPI_TOKEN env" },
                { status: 500 }
            );
        }

        const { searchParams } = new URL(req.url);

        const jobDocumentId = String(searchParams.get("jobDocumentId") || "").trim();
        const candidateDocumentId = String(searchParams.get("candidateDocumentId") || "").trim();

        if (!jobDocumentId || !candidateDocumentId) {
            return Response.json(
                { ok: false, error: "jobDocumentId and candidateDocumentId are required" },
                { status: 400 }
            );
        }

        const candidateId = await getCandidateId(base, token, candidateDocumentId);
        const rows = await getJobAssignments(base, token, jobDocumentId);

        const matched = rows.find((row) => {
            const rowCandidateId = relationId(row?.candidate);
            return String(rowCandidateId) === String(candidateId);
        });

        return Response.json({
            ok: true,
            candidateId,
            candidateProcessList: matched?.candidateProcessList || "",
            offerLetter: normalizeOfferLetterMedia(matched?.offerLetter),
        });
    } catch (e) {
        return Response.json(
            { ok: false, error: e?.message || "Server error" },
            { status: 500 }
        );
    }
}

/* ---------------- POST ---------------- */

export async function POST(req) {
    try {
        const base = strapiBase();
        const token = strapiToken();

        if (!base) {
            return Response.json(
                { ok: false, error: "Missing NEXT_PUBLIC_API_BASE_URL env" },
                { status: 500 }
            );
        }

        if (!token) {
            return Response.json(
                { ok: false, error: "Missing STRAPI_TOKEN env" },
                { status: 500 }
            );
        }

        const contentType = req.headers.get("content-type") || "";

        let jobDocumentId = "";
        let candidateDocumentId = "";
        let action = "";
        let uploadedOfferLetter = null;

        if (contentType.includes("multipart/form-data")) {
            const form = await req.formData();

            action = String(form.get("action") || "").trim();
            jobDocumentId = String(form.get("jobDocumentId") || "").trim();
            candidateDocumentId = String(form.get("candidateDocumentId") || "").trim();

            if (action !== "uploadOfferLetter") {
                return Response.json(
                    { ok: false, error: "Invalid multipart action" },
                    { status: 400 }
                );
            }

            const file = form.get("file");

            if (!file || typeof file === "string") {
                return Response.json(
                    { ok: false, error: "Offer letter file is required" },
                    { status: 400 }
                );
            }

            uploadedOfferLetter = await uploadOfferLetter(base, token, file);
        } else {
            const body = await req.json();

            action = String(body?.action || "").trim();
            jobDocumentId = String(body?.jobDocumentId || "").trim();
            candidateDocumentId = String(body?.candidateDocumentId || "").trim();
        }

        if (!jobDocumentId || !action) {
            return Response.json(
                { ok: false, error: "jobDocumentId and action are required" },
                { status: 400 }
            );
        }

        const rawRows = await getJobAssignments(base, token, jobDocumentId);
        const cleanRows = sanitizeAssignmentRows(rawRows);

        if (!cleanRows.length) {
            return Response.json(
                { ok: false, error: "No assignCandidatesToJob rows found" },
                { status: 404 }
            );
        }

        if (action === "clearSuggestedCandidates") {
            const updatedRows = cleanRows.filter(
                (row) => String(row?.candidateProcessList || "") !== "Suggested Candidate"
            );

            await updateJobAssignments(base, token, jobDocumentId, updatedRows);

            return Response.json({
                ok: true,
                action,
            });
        }

        if (!candidateDocumentId) {
            return Response.json(
                { ok: false, error: "candidateDocumentId is required" },
                { status: 400 }
            );
        }

        const candidateId = await getCandidateId(base, token, candidateDocumentId);

        if (action === "removeCandidate") {
            const targetRow = cleanRows.find(
                (row) => String(row?.candidate) === String(candidateId)
            );

            const wasHired =
                String(targetRow?.candidateProcessList || "") === "Hired Candidate";

            const updatedRows = cleanRows.filter(
                (row) => String(row?.candidate) !== String(candidateId)
            );

            await updateJobAssignments(base, token, jobDocumentId, updatedRows);

            if (wasHired) {
                await updateCandidateJobStatus(base, token, candidateDocumentId, "Available");
            }

            return Response.json({
                ok: true,
                action,
                candidateId,
                candidateJobStatusUpdatedTo: wasHired ? "Available" : null,
            });
        }

        let found = false;
        let previousProcess = "";
        let resultProcess = "";
        let resultOfferLetter = null;
        let nextProcessForCandidate = "";

        const updatedRows = cleanRows.map((row) => {
            if (String(row?.candidate) !== String(candidateId)) {
                return row;
            }

            found = true;
            previousProcess = row?.candidateProcessList || "";

            if (action === "uploadOfferLetter") {
                resultProcess = row?.candidateProcessList || "Hired Candidate";
                resultOfferLetter = uploadedOfferLetter;

                return {
                    ...row,
                    offerLetter: uploadedOfferLetter?.id || null,
                };
            }

            if (action === "removeOfferLetter") {
                resultProcess = row?.candidateProcessList || "";
                resultOfferLetter = null;

                return {
                    ...row,
                    offerLetter: null,
                };
            }

            const nextProcess = toProcessString(action);

            resultProcess = nextProcess;
            resultOfferLetter = row?.offerLetter
                ? normalizeOfferLetterMedia(row.offerLetter)
                : null;
            nextProcessForCandidate = nextProcess;

            return {
                ...row,
                candidateProcessList: nextProcess,
            };
        });

        if (!found) {
            return Response.json(
                { ok: false, error: "Candidate not found in assignCandidatesToJob" },
                { status: 404 }
            );
        }

        await updateJobAssignments(base, token, jobDocumentId, updatedRows);

        if (nextProcessForCandidate === "Hired Candidate") {
            await updateCandidateJobStatus(base, token, candidateDocumentId, "Hired");
        } else if (
            previousProcess === "Hired Candidate" &&
            nextProcessForCandidate &&
            nextProcessForCandidate !== "Hired Candidate"
        ) {
            await updateCandidateJobStatus(base, token, candidateDocumentId, "Available");
        }

        return Response.json({
            ok: true,
            action,
            candidateId,
            candidateProcessList: resultProcess,
            offerLetter: resultOfferLetter,
            candidateJobStatusUpdatedTo:
                nextProcessForCandidate === "Hired Candidate"
                    ? "Hired"
                    : previousProcess === "Hired Candidate" &&
                        nextProcessForCandidate !== "Hired Candidate"
                        ? "Available"
                        : null,
        });
    } catch (e) {
        return Response.json(
            { ok: false, error: e?.message || "Server error" },
            { status: 500 }
        );
    }
}